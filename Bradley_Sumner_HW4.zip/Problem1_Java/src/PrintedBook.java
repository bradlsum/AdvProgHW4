public class PrintedBook extends Book {
    // Printed book class
    public PrintedBook(){
        super();
    }

    public PrintedBook(String title, String location, int yearPub,
                       Author author, Publisher publisher){
        super(title, location, yearPub, author, publisher);
    }
}
